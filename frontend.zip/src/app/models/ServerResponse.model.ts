import { ProductModelServer } from './product.model';

// export interface  ServerResponse {
//     count : number;
//     products : ProductModelServer[];
//   }

  export interface  ServerResponse {
    products : ProductModelServer[];
  } 