export interface SignUp{
    fname : string;
    lname : string;
    email : string;
    password : string;
}

export interface SignIn{
    email : string;
    password : string;
}