export const environment = {
  production: true,
  SERVER_URL : "http://3.135.20.177:3000"
};
